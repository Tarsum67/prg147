import { useState } from "react";
import "./App.css";

// =================== PART 1: Conditional Rendering ===================
function ConditionalDemo() {
  // You may hard-code this true/false value
  const isTrue = true;

  return (
    <section className="demo-section">
      <h2>Conditional Rendering Demo</h2>

      {/* Terse conditional (ternary) from the video */}
      {isTrue ? (
        <p>The earth is spherical 🌍 (true)</p>
      ) : (
        <p>The earth is flat 🥞 (false)</p>
      )}
    </section>
  );
}

// ================= PART 2: Arrays & Destructuring ====================
function ArrayDemo() {
  // Array with 5 items
  const snacks = [
    "Chips",
    "Cookies",
    "Popcorn",
    "Trail Mix",
    "Fruit Snacks"
  ];

  // Destructuring – pulls them out into variables
  // NO index like snacks[3]; instead we use `fourth`
  const [first, second, third, fourth] = snacks;

  return (
    <section className="demo-section">
      <h2>Array & Destructuring Demo</h2>

      <h3>All Snacks:</h3>
      <ul>
        {snacks.map((snack) => (
          <div key={snack}>{snack}</div>
        ))}
      </ul>

      <h3>Only the 4th Snack (via variable):</h3>
      <p>{fourth}</p>
    </section>
  );
}

// =============== PART 3: useState & Automobile States ================
function CarStateDemo() {
  // useState to store & maintain the current car state
  const [carState, setCarState] = useState("Cruising");

  return (
    <section className="demo-section">
      <h2>Automobile State Demo</h2>

      {/* This is like the "emotion" example, but with car states */}
      <h3>Current State: {carState}</h3>

      <div className="button-row">
        <button onClick={() => setCarState("Cruising")}>Cruising</button>
        <button onClick={() => setCarState("Accelerating")}>Accelerating</button>
        <button onClick={() => setCarState("Braking")}>Braking</button>
      </div>
    </section>
  );
}

// ========================= MAIN APP COMPONENT ========================
export default function App() {
  return (
    <div className="App">
      <h1>Module 5 Assignment 3 Demo</h1>

      {/* Separate, labeled areas on the page */}
      <ConditionalDemo />
      <ArrayDemo />
      <CarStateDemo />
    </div>
  );
}
